package Interfaces;

public interface ColasTDA {
	void InicializarCola();
	void Acolar(int x);
	void Desacolar();
	boolean ColaVacia();
	int primero();
}
