package Interfaces;

public interface HeapTDA {
	void InicializarHeap();
	void Agregar(int x, int v);
	void Eliminar();
	int HijoIzq(int pos);
	int HijoDer(int pos);
	int Padre(int pos);
	boolean HeapVacio();
	ColasTDA prioridad();
	ColasTDA elementos();
}
