package Principal;

import Implementaciones.ColasIMP;
import Implementaciones.HeapIMP;
import Interfaces.ColasTDA;
import Interfaces.HeapTDA;

public class PrinHeap {
	
	public static ColasTDA CopiarCola(ColasTDA original) {
		ColasTDA copia = new ColasIMP();
		ColasTDA intermedia = new ColasIMP();
		copia.InicializarCola();
		intermedia.InicializarCola();
		while ( ! original.ColaVacia()) {
			intermedia.Acolar(original.primero());
			original.Desacolar();}
		while (! intermedia.ColaVacia()) {
			copia.Acolar(intermedia.primero());
			original.Acolar(intermedia.primero());
			intermedia.Desacolar();}
		return (copia);
	}

	public static void MostrarCola(ColasTDA original) {
		ColasTDA cola1 = CopiarCola(original);
		System.out.print("[");
		while (!cola1.ColaVacia()) {
			System.out.print(cola1.primero());
			cola1.Desacolar();
			if (! cola1.ColaVacia()) {
				System.out.print(",");}
			else {
				System.out.println("]");}
		}
	}

	public static void main(String[] args) {
		HeapTDA prueba = new HeapIMP();
		prueba.InicializarHeap();
		prueba.Agregar(30, 2);
		prueba.Agregar(15, 9);
		prueba.Agregar(20, 50);
		prueba.Agregar(4, 7);
		prueba.Eliminar();
		ColasTDA pruebaColaE = prueba.elementos();
		ColasTDA pruebaColaP = prueba.prioridad();
		MostrarCola(pruebaColaP);
		MostrarCola(pruebaColaE);
	}

}
