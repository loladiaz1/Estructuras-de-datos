package Implementaciones;

import Interfaces.ColasTDA;
import Interfaces.HeapTDA;

public class HeapIMP implements HeapTDA {
	
	class heap{
		int [] valores;
		int [] prioridad;
	}
	heap cola = new heap();
	int tamaño;
	
	@Override
	public void InicializarHeap() {
		cola.prioridad = new int[20];
		cola.valores = new int[20];
		tamaño = 1;
	}

	@Override
	public void Agregar(int x, int v) {
		cola.prioridad[tamaño] = x;
		cola.valores[tamaño] = v;
		if (tamaño != 1) {
			Revisar(tamaño);
		}
		tamaño ++;
	}

	private void Revisar(int pos) {
		int posPadre = Padre(pos);
		while (pos != 1 && cola.prioridad[pos] > cola.prioridad[posPadre]) {
			int aux = cola.prioridad[posPadre];
			int aux2 = cola.valores[posPadre];
			cola.prioridad[posPadre] = cola.prioridad[pos];
			cola.valores[posPadre] = cola.valores[pos];
			cola.prioridad[pos] = aux;
			cola.valores[pos] = aux2;
			pos = posPadre;
			posPadre = Padre(pos);
		}
	}
	
	
	@Override
	public void Eliminar() {
		if (! HeapVacio()) {
			int pos = 1;
			while(pos <= (tamaño/2)) {
				if (cola.prioridad[HijoIzq(pos)] != 0) {
					if (cola.prioridad[HijoIzq(pos)] > cola.prioridad[HijoDer(pos)]) {
						cola.prioridad[pos] = cola.prioridad[HijoIzq(pos)];
						cola.valores[pos] = cola.valores[HijoIzq(pos)];
						pos = HijoIzq(pos);
						}
					else {
						cola.prioridad[pos] = cola.prioridad[HijoDer(pos)];
						cola.valores[pos] = cola.valores[HijoDer(pos)];
						pos = HijoDer(pos);
					}
				}
				else
					break;
			}
			while(pos <= tamaño) {
				cola.prioridad[pos] = cola.prioridad[pos +1];
				cola.valores[pos] = cola.valores[pos +1];
				Revisar(pos);
				pos ++;
			}
			tamaño --;
		}

	}

	@Override
	public int HijoIzq(int pos) {
		return pos*2;
	}

	@Override
	public int HijoDer(int pos) {
		return pos*2+1;
	}
	
	@Override
	public int Padre(int pos) {
		return pos/2;
	}

	@Override
	public boolean HeapVacio() {
		return (tamaño == 1);
	}

	@Override
	public ColasTDA prioridad() {
		ColasTDA colaPrioridades = new ColasIMP();
		colaPrioridades.InicializarCola();
		for (int i = 1; i < tamaño; i ++)
			colaPrioridades.Acolar(cola.prioridad[i]);
		return colaPrioridades;
	}
	
	@Override
	public ColasTDA elementos() {
		ColasTDA colaElementos = new ColasIMP();
		colaElementos.InicializarCola();
		for (int i = 1; i < tamaño; i ++)
			colaElementos.Acolar(cola.valores[i]);
		return colaElementos;
	}


}
